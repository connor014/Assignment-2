//
//  ViewController.swift
//  Assignment 2
//
//  Created by Connor Dawson on 02/5/17.
//  Copyright © 2017 Connor Dawson. All rights reserved.
//
// link to youtube video: https://youtu.be/JULcqe_-Row

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    // Properties
    var playoverallscore = 0
    var comoverallscore = 0
    var playerscore = 0
    var comscore = 0
    var soundPlayer: AVAudioPlayer?
    var elapsedTime : TimeInterval = 0
    let cardnumbers = ["card0","card1","card2","card3","card4","card5","card6","card7","card8","card9","card10","card11","card12"]
    
    // Controls back option.
    @IBOutlet weak var back: UIButton!
    // Controls text displayed for settings.
    @IBOutlet weak var howto: UITextView!
    // Displays settings.
    @IBAction func settings(_ sender: Any) {
        howto.isHidden = false
        back.isHidden = false
    }
    
    // Allows user to close settings.
    @IBAction func Back(_ sender: Any) {
        howto.isHidden = true
        back.isHidden = true
    }
    
    // Controls what is displayed on left card.
    @IBOutlet weak var leftimageview: UIImageView!
    // Controls what is displayed on right card.
    @IBOutlet weak var rightimageview: UIImageView!
    
    // Contains main functions.
    @IBAction func drawcard(_ sender: UIButton)
    {
        // Randomises left card.
        let randomleft = Int(arc4random_uniform(13))
        leftimageview.image = UIImage(named: cardnumbers[randomleft])
        
        // Randomises right card.
        let randomright = Int(arc4random_uniform(13))
        rightimageview.image = UIImage(named: cardnumbers[randomright])
        
        // Compare card numbers.
        if randomleft > randomright{
            // Player card wins.
            // Increment the score.
            playerscore += 1
            Score.text = String(playerscore)
            // Update label.
            Label.text = "PLAYER has won."
            Label.isHidden = false

        }
        else if randomleft == randomright{
            // Its a draw.
            Label.text = "It's a draw."
            Label.isHidden = false
        }
        else{
            // Computer wins.
            // Increment the score.
            comscore += 1
            Score1.text = String(playerscore)
            // Update label.
            Label.text = "COM has won."
            Label.isHidden = false

        }
    }
    
    @IBAction func resetscores(_ sender: UIButton) {
        // Resets player score.
        playerscore = 0
        Score.text = String(playerscore)
        // Resets com score.
        comscore = 0
        Score1.text = String(playerscore)
    }
    
    
    // Label for players score.
    @IBOutlet weak var Score: UILabel!
    
    // Label for coms score.
    @IBOutlet weak var Score1: UILabel!
    
    // Label displays when game is over and displays winner.
    @IBOutlet weak var Label: UILabel!
    

    // Music player
    
    // Play
    @IBAction func Play(_ sender: UIButton) {
        if soundPlayer != nil {
            soundPlayer!.currentTime = elapsedTime
            soundPlayer!.play()
        }
    }
    
    // Pause
    @IBAction func Pause(_ sender: UIButton) {
        if soundPlayer != nil {
            elapsedTime = soundPlayer!.currentTime
            soundPlayer!.pause()
        }
        
    }
    
    // Stop
    @IBAction func stop(_ sender: UIButton) {
        if soundPlayer != nil {
            soundPlayer!.stop()
            elapsedTime = 0
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let path =
            Bundle.main.path(forResource: "bensound-ukulele", ofType: "mp3") //Music: http://www.bensound.com
        
        let url = URL(fileURLWithPath: path!)
        
        do {
            // set up the player by loading sound file
            try soundPlayer = AVAudioPlayer(contentsOf: url)
        }
            // catch the error if playback fails
        catch { print("file not available")}
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

